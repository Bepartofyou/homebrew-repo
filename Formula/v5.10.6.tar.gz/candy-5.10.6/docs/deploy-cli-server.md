# 部署 CLI 服务端

根据帮助信息 `candy --help` 和配置文件描述部署.

非专业用户请[部署 Web 服务端](https://docs.canets.org/deploy-web-server).

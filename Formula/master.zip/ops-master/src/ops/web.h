#ifndef __web_h__
#define __web_h__
#include "ops.h"
typedef struct _ops_web ops_web;

//创建模块
ops_web* web_new(ops_global* global);

#endif // !__web_h__
